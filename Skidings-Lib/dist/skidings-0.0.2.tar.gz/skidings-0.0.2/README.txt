[Skidings-lib Docs]

About this lib:

this library was primarly made for people that are getting into networking and sql databases, also requests library ect. this is just a shortcut for learning these librarys and makes you're code more simple and easier to use, this is a open source project so this means you are able to upload community versions of this applications and add and improve the current source code.