from skidings import *

ip = input("Enter a ip: ")

dns = dns_lookup(ip)

print(dns)

input()