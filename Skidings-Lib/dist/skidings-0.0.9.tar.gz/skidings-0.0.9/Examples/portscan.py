from skidings import *

ip = input("Enter a ip: ")

portscan = portscan(ip)

print(portscan)

input()