from skidings import *

time = current_time()

print(time)