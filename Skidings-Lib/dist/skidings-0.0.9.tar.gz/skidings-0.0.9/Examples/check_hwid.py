from skidings import *

hwid = get_hwid()
pastebin_url = "PASTEBIN URL"

check = check_hwid(paste_url,hwid)

print(check)

input()