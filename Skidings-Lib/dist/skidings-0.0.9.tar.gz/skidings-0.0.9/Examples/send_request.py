from skidings import *

url = "API URL"

request = send_request(url)

print(request)

input()