from skidings import *

content = input("Enter the contents: ")

encrypt = encrypt_key(content)

print(encrypt)

input()