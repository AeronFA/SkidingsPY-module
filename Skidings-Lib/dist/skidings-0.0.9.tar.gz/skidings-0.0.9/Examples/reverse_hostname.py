from skidings import *

hostname = input("Enter a hostname: ")

reverse = reverse_hostname(hostname)

print(reverse)

input()