from skidings import *

hwid = get_hwid()

print(hwid)

input()