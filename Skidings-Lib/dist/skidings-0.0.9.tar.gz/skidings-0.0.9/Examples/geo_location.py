from skidings import *

ip = input("Enter a ip: ")

lookup = geo_location(ip)

print(lookup)

input()