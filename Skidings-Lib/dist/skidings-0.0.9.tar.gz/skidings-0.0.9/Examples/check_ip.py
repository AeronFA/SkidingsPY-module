from skidings import *

pastebin_url = "PASTEBIN URL"

check = check_ip(paste_url)

print(check)

input()