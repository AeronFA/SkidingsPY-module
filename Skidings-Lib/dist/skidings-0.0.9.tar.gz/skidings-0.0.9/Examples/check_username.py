from skidings import *

username = input("Enter a username: ")
pastebin_url = "PASTEBIN URL"

check = check_user(paste_url,username)

print(check)

input()