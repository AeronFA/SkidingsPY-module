from skidings import *

ip = get_ip()

print(ip)

input()