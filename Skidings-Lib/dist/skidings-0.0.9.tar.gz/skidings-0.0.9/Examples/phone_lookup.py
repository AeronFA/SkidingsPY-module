from skidings import *

#International Number without (+)
phone_number = input("Enter a phone number: ")

lookup = phone_lookup(phone_lookup)

print(lookup)

input()