from skidings import *

password = input("Enter a password: ")
pastebin_url = "PASTEBIN URL"

check = check_password(paste_url,password)

print(check)

input()